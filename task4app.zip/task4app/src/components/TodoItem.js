import React from 'react';

const TodoItem = ({ todo, toggleComplete, deleteTodo }) => {
  return (
    <tr className={`todo-item ${todo.completed ? 'completed' : ''}`}>
      <td><span onClick={() => toggleComplete(todo.id)}>{todo.todo}</span></td>
      <td><button onClick={() => deleteTodo(todo.id)}>Delete</button></td>
    </tr>
  );
};

export default TodoItem;